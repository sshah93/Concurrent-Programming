//  This code written by someone else.
//  Attribution info stripped to make software usable for CS 511.

public class PoisonPill extends Page {
  public boolean isPoisonPill() { return true; }
}
