CS 511 A
Suketu Shah (sshah75) & Michael Peleshenko (mpeleshe)
Assignment 5 Folder

Steps to run it:

erl

Inside the erl shell:

c(sensor).
c(watcher).
watcher:watcher_start().
Type in the number of sensors to create at the prompt